package com.infy.utility;

public class GlobalEducationException extends Exception{
	private static final long serialVersionUID=1L;
	public GlobalEducationException(String message) {
		super(message);
} 
	}

