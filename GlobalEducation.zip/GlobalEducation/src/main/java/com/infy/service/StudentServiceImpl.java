package com.infy.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.dto.StudentDTO;
import com.infy.entity.Student;
import com.infy.repository.StudentRepository;
import com.infy.utility.GlobalEducationException;
import com.infy.validation.StudentValidator;

public class StudentServiceImpl implements StudentService {
	@Autowired
	StudentRepository studentrepository;
	@Override
	public StudentDTO registerStudent(StudentDTO studentDTO) throws GlobalEducationException{
		// TODO Auto-generated method stub
		StudentValidator.validateStudent(studentDTO);
		Optional<Student> mail=studentrepository.findByEmailId(studentDTO.getEmailId());
        if(mail.isPresent())
        	throw new GlobalEducationException("already present");
		Student	mystd=StudentDTO.prepareEntity(studentDTO);	
        studentrepository.save(mystd);
        mystd.setStudentId(studentDTO.getStudentId());
        StudentDTO delhi=StudentDTO.prepareDTO(mystd);
        return delhi;
	}
	@Override
	public List<StudentDTO> getStudentByCountryAndIntake(String country, Integer intakeYear) throws GlobalEducationException {
		// TODO Auto-generated method stub
		List<Student> ls=studentrepository.findByInterestedCountryAndIntakeYear(country, intakeYear);
		if(ls.isEmpty()) {
			throw new GlobalEducationException("no students found");
		}
        return ls.stream().map(student->{		
		StudentDTO finallist=StudentDTO.prepareDTO(student);
		return finallist;
		}).sorted((q1,q2)->q1.getStudentName().compareTo(q2.getStudentName())).collect(Collectors.toList());
	}
}
