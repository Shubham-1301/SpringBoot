package com.infy.service;

import java.util.List;

import com.infy.dto.StudentDTO;
import com.infy.utility.GlobalEducationException;

public interface StudentService {
	
	StudentDTO registerStudent( StudentDTO studentDTO) throws GlobalEducationException;
	List< StudentDTO> getStudentByCountryAndIntake(String country, Integer intakeYear) throws GlobalEducationException;

}
