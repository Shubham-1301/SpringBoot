package com.infy.dto;
import com.infy.entity.Student;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class StudentDTO {
	
	private Integer studentId;
	@NotNull(message= "{student_name_is_mandatory}")
	@Pattern(regexp="[A-Za-z/s]", message="{name can have only alphabets and space}")
	private String studentName;
	@NotNull(message="{email is mandatory}")
    @Pattern(regexp="[A-Za-z0-9](@gmail.com)", message= "{must be a valid emailid}")
	private String emailId;
	@NotNull(message="{interestedcountry is mandatory}")
	private String interestedCountry;
	@NotNull(message="{intake year is mandatory}")
	private Integer intakeYear;
	@NotNull(message= "{studylevel is mandatory}")
	private String studyLevel;
	@NotNull(message="{courseinterested is mandastory}")
	private String courseInterested;
	
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getInterestedCountry() {
		return interestedCountry;
	}
	public void setInterestedCountry(String interestedCountry) {
		this.interestedCountry = interestedCountry;
	}
	public Integer getIntakeYear() {
		return intakeYear;
	}
	public void setIntakeYear(Integer intakeYear) {
		this.intakeYear = intakeYear;
	}
	public String getStudyLevel() {
		return studyLevel;
	}
	public void setStudyLevel(String studyLevel) {
		this.studyLevel = studyLevel;
	}
	public String getCourseInterested() {
		return courseInterested;
	}
	public void setCourseInterested(String courseInterested) {
		this.courseInterested = courseInterested;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", emailId=" + emailId
				+ ", interestedCountry=" + interestedCountry + ", intakeYear=" + intakeYear + ", studyLevel="
				+ studyLevel + ", courseInterested=" + courseInterested + "]";
	}
	public StudentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static Student prepareEntity(StudentDTO studentdto) {
		Student mystudent= new Student();
		mystudent.setCourseInterested(studentdto.getCourseInterested());
		mystudent.setEmailId(studentdto.getEmailId());
		mystudent.setIntakeYear(studentdto.getIntakeYear());
		mystudent.setInterestedCountry(studentdto.getInterestedCountry());
		mystudent.setStudentId(studentdto.getStudentId());
		mystudent.setStudentName(studentdto.getStudentName());
		mystudent.setStudyLevel(studentdto.getStudyLevel());
		return mystudent;
	}
	
	
	public static StudentDTO prepareDTO (Student student) {
	StudentDTO mystudent= new StudentDTO();
	mystudent.setCourseInterested(student.getCourseInterested());
	mystudent.setEmailId(student.getEmailId());
	mystudent.setIntakeYear(student.getIntakeYear());
	mystudent.setInterestedCountry(student.getInterestedCountry());
	mystudent.setStudentId(student.getStudentId());
	mystudent.setStudentName(student.getStudentName());
	mystudent.setStudyLevel(student.getStudyLevel());
	return mystudent;
	}	
}
