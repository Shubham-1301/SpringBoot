package com.infy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.infy.entity.Student;

public interface StudentRepository extends CrudRepository<Student, Integer>{
	Optional<Student> findByEmailId(String emailId);
	List<Student> findByInterestedCountryAndIntakeYear(String interestedCountry, Integer intakeString);

}
