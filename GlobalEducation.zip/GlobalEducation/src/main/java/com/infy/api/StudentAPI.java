package com.infy.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.StudentDTO;
import com.infy.service.StudentService;
import com.infy.utility.GlobalEducationException;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
@RestController
@RequestMapping("global-edu")
@Validated
public class StudentAPI {
	@Autowired
	StudentService studentservice;
	@PostMapping("student")
	ResponseEntity< StudentDTO> registerStudent(@RequestBody StudentDTO studentDTO) throws GlobalEducationException {
		StudentDTO sdto=studentservice.registerStudent(studentDTO);
		return new ResponseEntity<>(sdto, HttpStatus.CREATED);
		
	}
	@GetMapping("student/{country}/{intakeYear}")
	ResponseEntity< List<StudentDTO>> getStudentByCountryAndIntake
	(String country,@PathVariable @Valid @Pattern(regexp="[0-9]{4}", message="IntakeYear should be of 4 digits")
	Integer intakeYear) throws GlobalEducationException{
		List<StudentDTO> lsdto=studentservice.getStudentByCountryAndIntake(country, intakeYear);
		return new ResponseEntity<>(lsdto, HttpStatus.OK); 
	}

}
