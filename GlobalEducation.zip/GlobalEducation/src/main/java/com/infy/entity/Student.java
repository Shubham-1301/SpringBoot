package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer studentId;
	private String studentName;
	private String emailId;
	private String interestedCountry;
	private Integer intakeYear;
	private String studyLevel;
	private String courseInterested;
	
	
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getInterestedCountry() {
		return interestedCountry;
	}
	public void setInterestedCountry(String interestedCountry) {
		this.interestedCountry = interestedCountry;
	}
	public Integer getIntakeYear() {
		return intakeYear;
	}
	public void setIntakeYear(Integer intakeYear) {
		this.intakeYear = intakeYear;
	}
	public String getStudyLevel() {
		return studyLevel;
	}
	public void setStudyLevel(String studyLevel) {
		this.studyLevel = studyLevel;
	}
	public String getCourseInterested() {
		return courseInterested;
	}
	public void setCourseInterested(String courseInterested) {
		this.courseInterested = courseInterested;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", emailId=" + emailId
				+ ", interestedCountry=" + interestedCountry + ", intakeYear=" + intakeYear + ", studyLevel="
				+ studyLevel + ", courseInterested=" + courseInterested + "]";
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
