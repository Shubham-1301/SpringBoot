package com.infy.validation;

import java.time.LocalDate;

import com.infy.dto.StudentDTO;
import com.infy.utility.GlobalEducationException;

public class StudentValidator {
	
	public static void validateStudent( StudentDTO studentdto) throws GlobalEducationException {
		if(isvalidIntakeYear(studentdto.getIntakeYear())==false)
			throw new GlobalEducationException("gggggg");
	
	}
	
	public static Boolean isvalidIntakeYear (Integer intakeYear) {
		if(intakeYear>LocalDate.now().getYear()) {
			return true;
	}else {
		return false;
	}
}
}