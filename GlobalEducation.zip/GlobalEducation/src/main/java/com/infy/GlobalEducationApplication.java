package com.infy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalEducationApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalEducationApplication.class, args);
	}

}
