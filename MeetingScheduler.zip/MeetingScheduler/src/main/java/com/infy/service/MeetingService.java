package com.infy.service;

import java.util.List;

import com.infy.dto.MeetingDTO;
import com.infy.utility.MeetingSchedulerException;

public interface MeetingService {
	List<MeetingDTO> getAllMeetingOfScheduler(String schedulerName) throws MeetingSchedulerException;
	MeetingDTO scheduleMeeting(MeetingDTO meetingDTO) throws MeetingSchedulerException;

}
