package com.infy.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dto.MeetingDTO;
import com.infy.entity.Meeting;
import com.infy.repository.MeetingRepository;
import com.infy.utility.MeetingSchedulerException;
import com.infy.validator.MeetingValidator;
@Service(value = "meetingService")
@Transactional
public class MeetingServiceImpl  implements MeetingService{
  @Autowired
  MeetingRepository meetingRepository;
	@Override
	public List<MeetingDTO> getAllMeetingOfScheduler(String schedulerName) throws MeetingSchedulerException {
		List<Meeting> mt = meetingRepository.findBySchedulerName(schedulerName);
		if(mt.isEmpty())
			throw new MeetingSchedulerException("schedulerName");
		return mt.stream().map(sy->{
			MeetingDTO shubham=MeetingDTO.prepareDTO(sy);
			return shubham;
		}).sorted((a1, a2)-> a1.getMeetingDate().compareTo(a2.getMeetingDate())).collect(Collectors.toList());	 }
	@Override
	public MeetingDTO scheduleMeeting(MeetingDTO meetingDTO) throws MeetingSchedulerException {
		MeetingValidator.validateMeeting(meetingDTO);
		List<Meeting> newlist=meetingRepository.findBySchedulerAndMeetingDate(meetingDTO.getSchedulerName(), meetingDTO.getMeetingDate());
        if(newlist!=null) {
        	throw new MeetingSchedulerException("meeting date unavailable"); }
        List<Meeting> teamlist=meetingRepository.findByTeamNameAndMeetingDate(meetingDTO.getTeamName(), meetingDTO.getMeetingDate());
        if(teamlist!=null){
        	throw new MeetingSchedulerException("team unavailable"); }
        Meeting meetingojt=MeetingDTO.prepareEntity(meetingDTO);
        meetingojt= meetingRepository.save(meetingojt);
        meetingDTO.setMeetingId(meetingojt.getMeetingId());
		return meetingDTO;
        }
}
