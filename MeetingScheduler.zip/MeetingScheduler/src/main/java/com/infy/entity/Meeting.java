package com.infy.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name ="meeting")
public class Meeting {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
 private Integer meetingId;
 private String schedulerName;
 private String TeamName;
 private String purpose;
 private LocalDate meetingDate;
 
 
 
 
public Meeting() {
	super();
	// TODO Auto-generated constructor stub
}
public Integer getMeetingId() {
	return meetingId;
}
public void setMeetingId(Integer meetingId) {
	this.meetingId = meetingId;
}
public String getSchedulerName() {
	return schedulerName;
}
public void setSchedulerName(String schedulerName) {
	this.schedulerName = schedulerName;
}
public String getTeamName() {
	return TeamName;
}
public void setTeamName(String teamName) {
	TeamName = teamName;
}
public String getPurpose() {
	return purpose;
}
public void setPurpose(String purpose) {
	this.purpose = purpose;
}
public LocalDate getMeetingDate() {
	return meetingDate;
}
public void setMeetingDate(LocalDate meetingDate) {
	this.meetingDate = meetingDate;
}
 
}
