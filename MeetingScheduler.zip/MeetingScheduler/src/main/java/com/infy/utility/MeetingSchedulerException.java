package com.infy.utility;

public class MeetingSchedulerException extends Exception {
		private static final long serialVersionUID=1L;
		public MeetingSchedulerException(String message) {
			super(message);
	} 

}
