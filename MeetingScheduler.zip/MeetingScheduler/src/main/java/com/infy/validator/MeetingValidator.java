package com.infy.validator;

import java.time.DayOfWeek;
import java.time.LocalDate;

import com.infy.dto.MeetingDTO;
import com.infy.utility.MeetingSchedulerException;

public class MeetingValidator {
		public static void validateMeeting(MeetingDTO meetingDTO) throws MeetingSchedulerException{
			if(!isValidMeetingDate(meetingDTO.getMeetingDate()))
			{
				throw new MeetingSchedulerException("not a valid schedule");
			}
			if(!isValidTeamName(meetingDTO.getTeamName())) {
				throw new MeetingSchedulerException("ggggggg");
			}

			
		}
		
        public   static Boolean isValidTeamName(String teamName) throws MeetingSchedulerException{
	    
        	return teamName.matches("ETAMYSJAVA|ETAMYSUI|ETAMYSBI|ETAMYSMS|ETAMYSAI");
        }
        
        public  static Boolean isValidMeetingDate(LocalDate meetingDate) throws MeetingSchedulerException{
	    return (!meetingDate.getDayOfWeek().equals(DayOfWeek.SATURDAY)|| meetingDate.getDayOfWeek().equals(DayOfWeek.SUNDAY));
	    }
}
