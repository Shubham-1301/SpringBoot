package com.infy.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.MeetingDTO;
import com.infy.service.MeetingService;
import com.infy.utility.MeetingSchedulerException;

import jakarta.validation.constraints.Pattern;
@RestController
@RequestMapping(value="api")
@Validated
public class MeetingAPI {
	@Autowired
	MeetingService meetingService;
	
	@GetMapping(value= "meetings/{schedulerName}")
	  public ResponseEntity<List<MeetingDTO>> getAllMeetingOfScheduler(@PathVariable @Pattern(regexp="[A-Za-z]*([/sa-zA-Z]+)", message="{meeting.schedulername.INVALID}") String schedulerName) throws MeetingSchedulerException {
	List<MeetingDTO> pyl=meetingService.getAllMeetingOfScheduler(schedulerName);
		return new ResponseEntity<>(pyl,HttpStatus.OK);

		  
	  }
	  
	  @PostMapping(value="meetings")
	  public ResponseEntity<MeetingDTO> scheduleMeeting(@RequestBody MeetingDTO meetingDTO) throws MeetingSchedulerException {
		MeetingDTO XYZ=meetingService.scheduleMeeting(meetingDTO);
		return new ResponseEntity<>(XYZ, HttpStatus.CREATED);
				
	  }

}
