package com.infy.dto;

import java.time.LocalDate;

import com.infy.entity.Meeting;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class MeetingDTO {
	

	 private Integer meetingId;
	 @NotNull(message = "{Kristy Payal  mahan hai}")
	 @Pattern(regexp="([A-Za-z]+) ([//sA-Za-z]+)*)",message = "{name.invalid}")
	 private String schedulerName;
	 @NotNull(message = "{teamname.not.present}")
	 private String TeamName;
	 @NotNull(message = "{purpose.not.present.kya ho gya}")
	 private String purpose;
	 @NotNull(message = "{date.not.present}")
	 @FutureOrPresent(message = "{date.invalid}")
	 private LocalDate meetingDate;
	 
	 
	 
	 
	public MeetingDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getMeetingId() {
		return meetingId;
	}
	public void setMeetingId(Integer meetingId) {
		this.meetingId = meetingId;
	}
	public String getSchedulerName() {
		return schedulerName;
	}
	public void setSchedulerName(String schedulerName) {
		this.schedulerName = schedulerName;
	}
	public String getTeamName() {
		return TeamName;
	}
	public void setTeamName(String teamName) {
		TeamName = teamName;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public LocalDate getMeetingDate() {
		return meetingDate;
	}
	public void setMeetingDate(LocalDate meetingDate) {
		this.meetingDate = meetingDate;
	}
	
	
	
	
public static Meeting prepareEntity (MeetingDTO meetingdto) {
	
	Meeting meeting=new Meeting();
	meeting.setMeetingDate(meetingdto.getMeetingDate());
	meeting.setMeetingId(meetingdto.getMeetingId());
	meeting.setPurpose(meetingdto.getPurpose());
	meeting.setSchedulerName(meetingdto.getSchedulerName());
	meeting.setTeamName(meetingdto.getTeamName());
	return meeting;
	
}


public static MeetingDTO prepareDTO (Meeting meeting) {
	
MeetingDTO meetingdto=new MeetingDTO();
meetingdto.setMeetingDate(meeting.getMeetingDate());
meetingdto.setMeetingId(meeting.getMeetingId());
meetingdto.setPurpose(meeting.getPurpose());
meetingdto.setSchedulerName(meeting.getSchedulerName());
meetingdto.setTeamName(meeting.getTeamName());
return meetingdto;

}	
	 
}
